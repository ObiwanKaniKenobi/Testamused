﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;
using Xunit;

Console.WriteLine("Executing LIST OF ALL OBJECTS GEt API................");

try
{
    string apiUrl = "https://api.restful-api.dev/objects"; // Replace with your API URL

    using (HttpClient client = new HttpClient())
    {
        HttpResponseMessage response = await client.GetAsync(apiUrl);

        if (response.IsSuccessStatusCode)
        {
            string content = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"API response: {content}");

            if(content != null)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("LIST OF ALL OBJECTS GEt API is working successfully.............");
            } else
            {
                Console.WriteLine("Response Body is null for LIST OF ALL OBJECTS GEt API");
            }
            

        }
        else
        {
            Console.WriteLine($"Error: {response.StatusCode}");
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Exception: {ex.Message}");
}




/* POST Request TEest
*/

Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");

Console.WriteLine("==============================Calling Add Object POST API=======================================");
Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");

String id = "";

try
{
    string apiUrl = "https://api.restful-api.dev/objects"; 

    var requestObj = new
    {
        name = "Apple MacBook Pro 16",
        data = new
        {
            year = 2019,
            price = 1849.99,
            CPU_model = "Intel Core i9",
            Hard_disk_size = "1 TB"
        }
    };

    using (HttpClient client = new HttpClient())
    {


        var jsonData = JsonConvert.SerializeObject(requestObj);
        var contentData = new StringContent(jsonData, Encoding.UTF8, "application/json");

        HttpResponseMessage response = await client.PostAsync(apiUrl, contentData);

        if (response.IsSuccessStatusCode)
        {
            string content = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"API response: {content}");
            var responseJson = JsonConvert.DeserializeObject<JObject>(content);
            id = responseJson["id"].ToString(); 

            if (content != null)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("ADD OBJECTS POST API is working successfully.............");
            }
            else
            {
                Console.WriteLine("Response Body is null for ADD OBJECTS POST API");
            }


        }
        else
        {
            Console.WriteLine($"Error in Add Object POST API: {response.StatusCode}");
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Exception in Add Object POST API: {ex.Message}");
}




/* Get a single object using the added ID
*/

Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");

Console.WriteLine("==============================Calling Get a single object using the added ID=======================================");
Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");

try
{
    string apiUrl = "https://api.restful-api.dev/objects/"+id; 

    using (HttpClient client = new HttpClient())
    {
        HttpResponseMessage response = await client.GetAsync(apiUrl);

        if (response.IsSuccessStatusCode)
        {
            string content = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"API response: {content}");

            if (content != null)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Calling Get a single object using the added ID.............");
            }
            else
            {
                Console.WriteLine("Response Body is null for Calling Get a single object using the added ID");
            }


        }
        else
        {
            Console.WriteLine($"Error: {response.StatusCode}");
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Exception: {ex.Message}");
}




/* PUT Request TEest
*/

Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");

Console.WriteLine("==============================Update the object added in step 2 using PUT=======================================");
Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");

try
{
    string apiUrl = "https://api.restful-api.dev/objects/"+id;

    var requestObj = new
    {
        name = "Apple MacBook Pro 17",
        data = new
        {
            year = 2020,
            price = 1859.99,
            CPU_model = "Intel Core i13",
            Hard_disk_size = "2 TB"
        }
    };

    using (HttpClient client = new HttpClient())
    {


        var jsonData = JsonConvert.SerializeObject(requestObj);
        var contentData = new StringContent(jsonData, Encoding.UTF8, "application/json");

        HttpResponseMessage response = await client.PutAsync(apiUrl, contentData);

        if (response.IsSuccessStatusCode)
        {
            string content = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"API response: {content}");
            var responseJson = JsonConvert.DeserializeObject<JObject>(content);
            id = responseJson["id"].ToString();

            if (content != null)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Update the object added in step 2 using PUT API is working successfully.............");
            }
            else
            {
                Console.WriteLine("successfull");
            }


        }
        else
        {
            Console.WriteLine($"Error in PUT API: {response.StatusCode}");
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Exception in PUT API: {ex.Message}");
}




/* DELETE Request TEest
*/

Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");

Console.WriteLine("==============================Calling Delete the object using DELETE=======================================");
Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("");


try
{
    string apiUrl = "https://api.restful-api.dev/objects/"+id;

    var requestObj = new
    {
        name = "Apple MacBook Pro 17",
        data = new
        {
            year = 2020,
            price = 1859.99,
            CPU_model = "Intel Core i13",
            Hard_disk_size = "2 TB"
        }
    };

    using (HttpClient client = new HttpClient())
    {


        var jsonData = JsonConvert.SerializeObject(requestObj);
        var contentData = new StringContent(jsonData, Encoding.UTF8, "application/json");

        HttpResponseMessage response = await client.DeleteAsync(apiUrl);

        if (response.IsSuccessStatusCode)
        {
            string content = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"API response: {content}");
            var responseJson = JsonConvert.DeserializeObject<JObject>(content);
            id = responseJson["id"].ToString();

            if (content != null)
            {
                Console.WriteLine("");
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine("Delete the object using DELETE");
            }


        }
        else
        {
            Console.WriteLine($"Error in Delete: {response.StatusCode}");
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine($"Exception in Delete: {ex.Message}");
}